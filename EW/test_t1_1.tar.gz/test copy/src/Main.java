public class Main {
    public static void main(String[] args) {
        FishmongerShop shop = new FishmongerShop();
        Fishmonger fishmonger = new Fishmonger(shop);
        Customer customer = new Customer(shop);

        fishmonger.start();
        customer.start();

        try {
            fishmonger.join();
            customer.join();
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Simulation complete.");
    }
}